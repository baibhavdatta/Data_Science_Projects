requirements:
torch==2.2.0.post100 
seaborn==0.12.2 
matplotlib==3.7.2 
numpy==1.24.3 
pandas==1.5.3
sklearn==1.3.0

setup_instructions:
	1	Extract all the files from the zip file 
	2	Open the TestModels.ipynb file in Jupyter Notebook or Google Colab
	3	Run all the cells in order
	4	The initial cells contains importing libraries, loading the dataset, loading the trained models, defining necessary functions,  preparing the dataset, defining the model classes
	5	Then there are two groups of cells marker with headings, for testing LSTM and for testing GRU. Run the cells under these headings to make predictions on the test data using the trained model which has been loaded using torch.load. This part shows the RMSE, MAE, and the Actual vs Predicted graph for the models.
